Proyecto VolleyLive v10

Ejemplo de estructura modular con layouts y control.