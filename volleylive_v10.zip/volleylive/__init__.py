from flask import Flask
from flask_socketio import SocketIO

socketio = SocketIO(cors_allowed_origins="*")

def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = 'secret!'
    from .api import routes as api_routes
    app.register_blueprint(api_routes.bp)
    socketio.init_app(app)
    return app
